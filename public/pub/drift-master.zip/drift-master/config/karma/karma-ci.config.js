module.exports = require("./karma.config").ci;

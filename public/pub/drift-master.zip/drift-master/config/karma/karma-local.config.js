module.exports = require("./karma.config").local;

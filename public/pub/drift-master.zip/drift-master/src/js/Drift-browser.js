// This file is used for the standalone browser build

import Drift from "./Drift";

window["Drift"] = Drift;
